package com.example.products_shop.entities.categories;

public class CategoryImportDTO {
    private String name;

    public String getName() {
        return name;
    }
}

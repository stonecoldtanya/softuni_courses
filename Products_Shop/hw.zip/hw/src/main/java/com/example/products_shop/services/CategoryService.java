package com.example.products_shop.services;

public interface CategoryService {
}

package com.example.products_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsShopApplicationTests {

    @Test
    void contextLoads() {
    }

}

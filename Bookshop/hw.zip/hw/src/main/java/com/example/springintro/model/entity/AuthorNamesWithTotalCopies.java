package com.example.springintro.model.entity;

public interface AuthorNamesWithTotalCopies {
    String getFirstName();
    String getLastName();
    long getTotalCopies();
}

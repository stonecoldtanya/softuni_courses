package com.example.xml_product_shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlProductShopApplication {

    public static void main(String[] args) {
        SpringApplication.run(XmlProductShopApplication.class, args);
    }

}

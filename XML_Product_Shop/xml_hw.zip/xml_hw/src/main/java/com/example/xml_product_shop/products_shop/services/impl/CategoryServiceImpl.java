package com.example.xml_product_shop.products_shop.services.impl;

public class CategoryServiceImpl {
}

package com.example.xml_product_shop.products_shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsShopApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductsShopApplication.class, args);
    }

}

package com.example.xml_product_shop.products_shop.entities.products;

public class ExportNamePriceProductDTO {
}

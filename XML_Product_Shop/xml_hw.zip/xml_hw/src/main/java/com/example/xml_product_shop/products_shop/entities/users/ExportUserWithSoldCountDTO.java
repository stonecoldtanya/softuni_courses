package com.example.xml_product_shop.products_shop.entities.users;

public class ExportUserWithSoldCountDTO {
}

package com.example.xml_product_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlProductShopApplicationTests {

    @Test
    void contextLoads() {
    }

}

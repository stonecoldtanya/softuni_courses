package Task5_BillPaymentsSystem.entities;

public enum CardType {
    VISA,
    MASTERCARD
}
